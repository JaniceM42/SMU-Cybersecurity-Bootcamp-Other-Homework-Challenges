#!/bin/bash

hour="$1"
date=$2

grep "$hour" /home/sysadmin/Lucky_Duck_Investigations/Roulette_Loss_Investigation/Dealer_Analysis/$date'_Dealer_schedule.txt' | awk -F" " '{print $1, $2, '$3', '$4'}' 


# time must be entered in quotations marks when running the script to ensure AM/PM argument is properly included.
# Ex: roulette_dealer_finder_by_time_and_game.sh  "05:00:00 AM" date '$3' '$4'
# When running for Blackjack, use "time" date '$3' '$4'
# When running for Roulette, use "time" date '$5' '$6'
# When running for TexasHol Em, use "time" date '$7' '$8'
