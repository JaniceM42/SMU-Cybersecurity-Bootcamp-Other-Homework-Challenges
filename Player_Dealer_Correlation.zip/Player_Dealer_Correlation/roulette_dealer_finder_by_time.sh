#!/bin/bash

hour="$1"
date=$2

grep "$hour" /home/sysadmin/Lucky_Duck_Investigations/Roulette_Loss_Investigation/Dealer_Analysis/$date'_Dealer_schedule.txt' | awk -F" " '{print $1, $2, $5, $6}' 


# time must be entered in quotations marks when running the script to ensure AM/PM argument is properly included.
# Ex: bash script.sh  "05:00:00 AM" date





