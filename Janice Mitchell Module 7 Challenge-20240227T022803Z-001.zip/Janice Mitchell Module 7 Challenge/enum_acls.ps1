$directory = Get-ChildItem -Path $PWD

foreach ($item in $directory) {
Get-Acl 
}